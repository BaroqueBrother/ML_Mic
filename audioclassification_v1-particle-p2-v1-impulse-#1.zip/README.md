# Particle Firmware

This folder contains firmware for the Particle Photon 2 device. The firmware includes an Edge Impulse model and full ingestion capabilities.

## Ingestion
Running ingestion requires the [edge-impulse-cli](https://www.npmjs.com/package/edge-impulse-cli). After installing the tools the daemon can be started by running:
```
$ edge-impulse-daemon
```
Note that connecting to Edge Impulse requires an account

## Inference
The `edge-impulse-cli` also includes a tool to run inference which can be started by the following command:
```
$ edge-impulse-run-impulse
```

## Flashing firmware to the Photon 2

Flashing your Particle device requires the Particle command line tool. Follow these [instructions](https://docs.particle.io/getting-started/developer-tools/cli/) to install the tools.

Once the tool is installed, following command is used to upload a binary to the device:
```
particle flash --local firmware-particle.bin